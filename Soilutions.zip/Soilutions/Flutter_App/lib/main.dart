import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'services/dataset_service.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Farmer Assist',
      theme: ThemeData(primarySwatch: Colors.green),
      home: const MoistureScreen(),
    );
  }
}

class MoistureScreen extends StatefulWidget {
  const MoistureScreen({super.key});
  @override
  State<MoistureScreen> createState() => _MoistureScreenState();
}

class _MoistureScreenState extends State<MoistureScreen> {
  final DatasetService _datasetService = DatasetService();

  List<String> _soilTypes = [];
  List<String> _crops = [];
  String? _selectedSoil;
  String? _selectedCrop;
  int? _currentMoisture;
  String _recommendation = '';
  final _ipController = TextEditingController(text: '192.168.205.24');

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    await _datasetService.loadDataset();
    setState(() {
      _soilTypes = _datasetService.getSoilTypes();
      _crops = _datasetService.getCrops();
    });
  }

  Future<void> _fetchAndCompare() async {
    if (_selectedSoil == null || _selectedCrop == null) {
      setState(() {
        _recommendation = 'Please select both soil type and crop.';
      });
      return;
    }
    final url = Uri.parse('http://${_ipController.text}/');
    try {
      final resp = await http.get(url).timeout(const Duration(seconds: 5));
      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body) as Map<String, dynamic>;
        final moisture = (data['moisture'] as num).toInt();
        final ideal = _datasetService.getIdealMoisture(_selectedSoil!, _selectedCrop!);
        String rec;
        if (ideal == null) {
          rec = 'No dataset entry for this soil+crop.';
        } else if (moisture < ideal) {
          rec = '🔺 Water Required: HIGH';
        } else if (moisture < ideal + 5) {
          rec = '⚠️ Water Required: MEDIUM';
        } else {
          rec = '✅ Water Required: LOW/NONE';
        }
        setState(() {
          _currentMoisture = moisture;
          _recommendation = rec;
        });
      } else {
        setState(() => _recommendation = 'Error: Server returned ${resp.statusCode}');
      }
    } catch (e) {
      setState(() => _recommendation = 'Error: $e');
    }
  }

  @override
  void dispose() {
    _ipController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Farmer Assist')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _ipController,
              decoration: const InputDecoration(
                labelText: 'ESP32 IP Address',
                prefixIcon: Icon(Icons.wifi),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _selectedSoil,
              decoration: const InputDecoration(labelText: 'Soil Type'),
              items: _soilTypes
                  .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                  .toList(),
              onChanged: (v) => setState(() {
                _selectedSoil = v;
              }),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _selectedCrop,
              decoration: const InputDecoration(labelText: 'Crop'),
              items: _crops
                  .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                  .toList(),
              onChanged: (v) => setState(() {
                _selectedCrop = v;
              }),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _fetchAndCompare,
              child: const Text('Get Recommendation'),
            ),
            if (_currentMoisture != null) ...[
              const SizedBox(height: 24),
              Text('Current Moisture: $_currentMoisture%', style: const TextStyle(fontSize: 20)),
              const SizedBox(height: 12),
              Text(_recommendation, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ],
          ],
        ),
      ),
    );
  }
}

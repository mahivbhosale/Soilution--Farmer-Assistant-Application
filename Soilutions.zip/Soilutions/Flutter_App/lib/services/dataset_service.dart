import 'package:flutter/services.dart' show rootBundle;
import 'package:csv/csv.dart';

/// Model for a single dataset entry
class SoilCropMoisture {
  final String soilType;
  final String crop;
  final int idealMoisture;

  SoilCropMoisture({
    required this.soilType,
    required this.crop,
    required this.idealMoisture,
  });
}

class DatasetService {
  List<SoilCropMoisture> _entries = [];
  bool _loaded = false;

  /// Load and parse the CSV into `_entries`
  Future<void> loadDataset() async {
    if (_loaded) return;
    final raw = await rootBundle.loadString('assets/indian_soil_crop_moisture_dataset.csv');
    final List<List> rows = const CsvToListConverter().convert(raw, eol: '\n');
    // Skip header
    _entries = rows.skip(1).map((row) {
      return SoilCropMoisture(
        soilType: row[0] as String,
        crop: row[1] as String,
        idealMoisture: (row[2] as num).toInt(),
      );
    }).toList();
    _loaded = true;
  }

  /// Get the ideal moisture for a soil+crop pair, or null if not found
  int? getIdealMoisture(String soilType, String crop) {
    try {
      return _entries
          .firstWhere((e) => e.soilType == soilType && e.crop == crop)
          .idealMoisture;
    } catch (_) {
      return null;
    }
  }

  /// Get a unique list of soil types
  List<String> getSoilTypes() =>
      _entries.map((e) => e.soilType).toSet().toList()..sort();

  /// Get a unique list of crops
  List<String> getCrops() =>
      _entries.map((e) => e.crop).toSet().toList()..sort();
}

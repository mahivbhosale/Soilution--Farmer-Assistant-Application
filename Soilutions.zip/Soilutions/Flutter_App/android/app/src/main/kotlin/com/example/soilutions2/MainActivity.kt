package com.example.soilutions2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
